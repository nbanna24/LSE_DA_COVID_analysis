####Assignment4####
# Install tidyverse library.
install.packages('tidyverse')
library(tidyverse)

# Import the data set.
turtle_sales <- read.csv(file.choose(), header = TRUE)

# View data frame.
head(turtle_sales)

# Data frame subset.
t_sales <- subset(turtle_sales, select = -c(Ranking, Year, Genre, Publisher))

# View data frame.
head(t_sales)

# Statistics summary.
summary(t_sales)

# Create two scatter plots.
qplot(EU_Sales, Global_Sales, data=t_sales)
qplot(NA_Sales, Global_Sales, data=t_sales)

# Create three histograms.
qplot(EU_Sales, bins=25, data=t_sales)
qplot(NA_Sales, bins=25, data=t_sales)
qplot(Global_Sales, bins=25, data=t_sales)

# Create three box plots.
qplot(EU_Sales, data= t_sales, geom="boxplot")
qplot(NA_Sales, data= t_sales, geom="boxplot")
qplot(Global_Sales, data= t_sales, geom="boxplot")

####Assignment 5####
# Check Sales min, max and mean per Region
min(t_sales$EU_Sales)
min(t_sales$NA_Sales)
min(t_sales$Global_Sales)

max(t_sales$EU_Sales)
max(t_sales$NA_Sales)
max(t_sales$Global_Sales)

mean(t_sales$EU_Sales)
mean(t_sales$NA_Sales)
mean(t_sales$Global_Sales)

# Group by products
t_products <- t_sales %>% group_by(Product) %>% summarise(across(.cols = c(NA_Sales, EU_Sales, Global_Sales), list(sum = sum)))

# View data frame.
head(t_products)

# Summary data frame
summary(t_products)

# Create two scatter plot.
qplot(EU_Sales_sum, Global_Sales_sum, data=t_products)
qplot(NA_Sales_sum, Global_Sales_sum, data=t_products)

# Create three histograms.
qplot(EU_Sales_sum, bins=25, data=t_products)
qplot(NA_Sales_sum, bins=25, data=t_products)
qplot(Global_Sales_sum, bins=25, data=t_products)

# Create three box plots.
qplot(EU_Sales_sum, data= t_products, geom="boxplot")
qplot(NA_Sales_sum, data= t_products, geom="boxplot")
qplot(Global_Sales_sum, data= t_products, geom="boxplot")

# Create Q-Q plots.
qqnorm(t_products$EU_Sales_sum)
qqline(t_products$EU_Sales_sum)

qqnorm(t_products$NA_Sales_sum)
qqline(t_products$NA_Sales_sum)


qqnorm(t_products$Global_Sales_sum)
qqline(t_products$Global_Sales_sum)

# Create Shapiro-Wilk test.
shapiro.test((t_products$EU_Sales_sum))
shapiro.test((t_products$NA_Sales_sum))
shapiro.test((t_products$Global_Sales_sum))

# Install moments package
install.packages("moments")
library(moments)

# Determine skewness and kurtosis.
skewness(t_products$EU_Sales_sum) 
kurtosis(t_products$EU_Sales_sum) 

skewness(t_products$NA_Sales_sum)
kurtosis(t_products$NA_Sales_sum)

skewness(t_products$Global_Sales_sum)
kurtosis(t_products$Global_Sales_sum)

# Determine correlation
cor(t_products$EU_Sales_sum, t_products$NA_Sales_sum)
cor(t_products$EU_Sales_sum, t_products$Global_Sales_sum)
cor(t_products$NA_Sales_sum, t_products$Global_Sales_sum)

# Insights
ggplot(data=t_products, 
       mapping=aes(x=Global_Sales_sum, y=NA_Sales_sum)) + 
  geom_point(color = "red",
             alpha = .5,
             size = 3) + geom_smooth(method = "lm")

ggplot(data=t_products, 
       mapping=aes(x=Global_Sales_sum, y=EU_Sales_sum)) + 
  geom_point(color = "red",
             alpha = .5,
             size = 3) + geom_smooth(method = "lm")

ggplot(data=t_products, 
       mapping=aes(x=NA_Sales_sum, y=EU_Sales_sum)) + 
  geom_point(color = "red",
             alpha = .5,
             size = 3) + geom_smooth(method = "lm")

####Assignment6####
# View data frame.
head(t_products)

# determine correlation between columns
cor(t_products)

# Create new data frames for linear regression (lr)
lr_1 <- select(t_products,EU_Sales_sum, Global_Sales_sum)
lr_2 <- select(t_products,NA_Sales_sum, Global_Sales_sum)
lr_3 <- select(t_products,EU_Sales_sum, NA_Sales_sum)

# Create a model with only one x variable for each data frame
model_1 <-lm(EU_Sales_sum ~ Global_Sales_sum, data = lr_1)
model_2 <-lm(NA_Sales_sum ~ Global_Sales_sum, data = lr_2)
model_3 <-lm(EU_Sales_sum ~ NA_Sales_sum, data = lr_3)

# View more outputs for the model - the full regression table.
summary(model_1)
summary(model_2)
summary(model_3)


# View residuals on a plot.
plot(model_1$residuals)
plot(model_2$residuals)
plot(model_3$residuals)

# Plot the relationships with base R graphics.
plot(lr_1$EU_Sales_sum,lr_1$Global_Sales_sum)
# Add line-of-best-fit.
abline(coefficients(model_1))

# Plot the relationships with base R graphics.
plot(lr_2$NA_Sales_sum,lr_2$Global_Sales_sum)
# Add line-of-best-fit.
abline(coefficients(model_2))


# Plot the relationships with base R graphics.
plot(lr_3$EU_Sales_sum,lr_3$NA_Sales_sum)
# Add line-of-best-fit.
abline(coefficients(model_3))

# Create a model with multiple linear regression
model_4 =lm(Global_Sales_sum ~ EU_Sales_sum+NA_Sales_sum,data = t_products  )

# View more outputs for the model - the full regression table.
summary(model_4)


# Predict global sales (PGS) based on provided values

# Create Data frame
NA_Sales_sum<-(34.02)
EU_Sales_sum<-(23.80)

PGS_a<- data.frame(NA_Sales_sum, EU_Sales_sum)

# Model with PGS
predict(model_4, newdata = PGS_a, interval='confidence')

# Create Data frame
NA_Sales_sum<-(3.93)
EU_Sales_sum<-(1.56)

PGS_b<- data.frame(NA_Sales_sum, EU_Sales_sum)

# Model with PGS
predict(model_4, newdata = PGS_b, interval='confidence')

# Create Data frame
NA_Sales_sum<-(2.73)
EU_Sales_sum<-(0.65)

PGS_c<- data.frame(NA_Sales_sum, EU_Sales_sum)

# Model with PGS
predict(model_4, newdata = PGS_c, interval='confidence')

# Create Data frame
NA_Sales_sum<-(2.26)
EU_Sales_sum<-(0.97)

PGS_d<- data.frame(NA_Sales_sum, EU_Sales_sum)

# Model with PGS
predict(model_4, newdata = PGS_d, interval='confidence')

# Create Data frame
NA_Sales_sum<-(22.08)
EU_Sales_sum<-(0.52)

PGS_e<- data.frame(NA_Sales_sum, EU_Sales_sum)

# Model with PGS
predict(model_4, newdata = PGS_e, interval='confidence')
